var nota1Html = document.getElementById("nota1Html");
var nota2Html = document.getElementById("nota2Html");
var nota3Html = document.getElementById("nota3Html");
var promedioHtml = 0;
var resultadoHtml = document.getElementById("promedioHtml");
var sumaHtml = 0;

console.log(sumaHtml)

sumaHtml = parseInt(prompt("Ingrese nota 1 (HTML)"));
console.log(sumaHtml)
nota1Html.innerHTML = sumaHtml;
promedioHtml = promedioHtml + sumaHtml;
sumaHtml = parseInt(prompt("Ingrese nota 2 (HTML)"));
nota2Html.innerHTML = sumaHtml;
promedioHtml = promedioHtml + sumaHtml;
sumaHtml = parseInt(prompt("Ingrese nota 3 (HTML)"));
nota3Html.innerHTML = sumaHtml;
promedioHtml = promedioHtml + sumaHtml;
promedioHtml = promedioHtml/3;

resultadoHtml.innerHTML = promedioHtml;

var nota1Css = document.getElementById("nota1Css");
var nota2Css = document.getElementById("nota2Css");
var nota3Css = document.getElementById("nota3Css");
var promedioCss = 0;
var resultadoCss = document.getElementById("promedioCss");
var sumaCss = 0;

sumaCss = parseInt(prompt ("Ingrese nota 1 (CSS)"));
nota1Css.innerHTML = sumaCss;
promedioCss = promedioCss + sumaCss;
sumaCss = parseInt(prompt("Ingrese nota 2 (CSS)"));
nota2Css.innerHTML = sumaCss;
promedioCss = promedioCss + sumaCss;
sumaCss = parseInt(prompt("Ingrese nota 3 (CSS)"));
nota3Css.innerHTML = sumaCss;
promedioCss = promedioCss + sumaCss;
promedioCss = promedioCss/3;

resultadoCss.innerHTML = promedioCss;

var nota1Js = document.getElementById("nota1Js");
var nota2Js = document.getElementById("nota2Js");
var nota3Js = document.getElementById("nota3Js");
var promedioJs = 0;
var resultadoJs = document.getElementById("promedioJs");
var sumaJs = 0;

sumaJs = parseInt (prompt("Ingrese nota 1 (JavaScript)"));
nota1Js.innerHTML = sumaJs;
promedioJs = promedioJs + sumaJs;
sumaJs = parseInt (prompt("Ingrese nota 2 (JavaScript)"));
nota2Js.innerHTML = sumaJs;
promedioJs = promedioJs + sumaJs;
sumaJs = parseInt (prompt("Ingrese nota 3 (JavaScript)"));
nota3Js.innerHTML = sumaJs;
promedioJs = promedioJs + sumaJs;
promedioJs = promedioJs/3;

resultadoJs.innerHTML = promedioJs